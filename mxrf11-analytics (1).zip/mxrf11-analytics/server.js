'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { URL } = require('node:url');

const ROOT = __dirname;
const PORT = Number(process.env.PORT || 3000);
const BRAPI_BASE = 'https://brapi.dev';
const BRAPI_TOKEN = process.env.BRAPI_TOKEN || '';
let newsCache = { fetchedAt: 0, items: [] };

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml'
};

function sendJson(res, status, payload) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  });
  res.end(JSON.stringify(payload));
}

function isDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) return false;
  const date = new Date(`${value}T12:00:00Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

async function fetchBrapi(pathname, params) {
  const url = new URL(pathname, BRAPI_BASE);
  Object.entries(params).forEach(([key, value]) => url.searchParams.set(key, value));
  const headers = { Accept: 'application/json' };
  if (BRAPI_TOKEN) headers.Authorization = `Bearer ${BRAPI_TOKEN}`;
  const response = await fetch(url, { headers, signal: AbortSignal.timeout(15000) });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = body.message || body.error || `Provedor respondeu HTTP ${response.status}`;
    throw new Error(message);
  }
  return body;
}

async function getHistory(url, res) {
  const startDate = url.searchParams.get('startDate') || '';
  const endDate = url.searchParams.get('endDate') || new Date().toISOString().slice(0, 10);
  if (!isDate(startDate) || !isDate(endDate) || startDate > endDate || startDate < '2012-04-13' || endDate > new Date().toISOString().slice(0, 10)) {
    return sendJson(res, 400, { error: 'Informe datas válidas entre 2012-04-13 e hoje.' });
  }
  try {
    const body = await fetchBrapi('/api/v2/fii/historical', { symbols: 'MXRF11', startDate, endDate, sortOrder: 'asc' });
    const fund = (body.fiis || []).find((item) => item.symbol === 'MXRF11') || (body.fiis || [])[0];
    const raw = fund?.historicalDataPrice || [];
    const data = raw.map((point) => ({
      date: new Date(Number(point.date) * 1000).toISOString().slice(0, 10),
      open: Number(point.open),
      high: Number(point.high),
      low: Number(point.low),
      close: Number(point.close),
      adjustedClose: Number(point.adjustedClose),
      volume: Number(point.volume)
    })).filter((point) => isDate(point.date) && Number.isFinite(point.close));
    sendJson(res, 200, { symbol: 'MXRF11', source: 'brapi.dev · histórico diário', data, requestedAt: body.requestedAt || new Date().toISOString() });
  } catch (error) {
    sendJson(res, 502, { error: `Não foi possível consultar o histórico: ${error.message}` });
  }
}

async function getIndicators(res) {
  try {
    const body = await fetchBrapi('/api/v2/fii/indicators', { symbols: 'MXRF11' });
    sendJson(res, 200, body);
  } catch (error) {
    sendJson(res, 502, { error: `Não foi possível consultar os indicadores: ${error.message}` });
  }
}

function decodeXml(value) {
  return String(value || '')
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'")
    .trim();
}
function readTag(block, tag) {
  const match = block.match(new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${tag}>`, 'i'));
  return match ? decodeXml(match[1]).replace(/<[^>]*>/g, '').trim() : '';
}

async function getNews(res) {
  const now = Date.now();
  if (newsCache.items.length && now - newsCache.fetchedAt < 5 * 60 * 1000) {
    return sendJson(res, 200, { items: newsCache.items, cached: true, checkedAt: new Date(newsCache.fetchedAt).toISOString(), source: 'Google News RSS' });
  }
  try {
    const rssUrl = 'https://news.google.com/rss/search?q=MXRF11%20OR%20%22Maxi%20Renda%22&hl=pt-BR&gl=BR&ceid=BR:pt-419';
    const response = await fetch(rssUrl, { headers: { 'User-Agent': 'MXRF11-Analytics/0.1 (open-source educational project)' }, signal: AbortSignal.timeout(12000) });
    if (!response.ok) throw new Error(`Feed respondeu HTTP ${response.status}`);
    const xml = await response.text();
    const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/gi)].slice(0, 12).map((match) => {
      const block = match[1];
      const title = readTag(block, 'title');
      const link = readTag(block, 'link');
      const source = readTag(block, 'source') || 'Google News';
      const pubDate = readTag(block, 'pubDate');
      const parsedDate = pubDate ? new Date(pubDate) : new Date();
      return { title, link, source, date: Number.isNaN(parsedDate.getTime()) ? null : parsedDate.toISOString() };
    }).filter((item) => item.title && /^https?:\/\//i.test(item.link));
    newsCache = { fetchedAt: now, items };
    sendJson(res, 200, { items, cached: false, checkedAt: new Date(now).toISOString(), source: 'Google News RSS' });
  } catch (error) {
    sendJson(res, 502, { error: `Não foi possível atualizar as notícias: ${error.message}` });
  }
}

function serveStatic(urlPath, res, headOnly = false) {
  let pathname;
  try { pathname = decodeURIComponent(urlPath); } catch (_) { return sendJson(res, 400, { error: 'Caminho inválido.' }); }
  if (pathname === '/') pathname = '/index.html';
  const normalized = path.normalize(pathname).replace(/^([.][.][/\\])+/, '');
  const filePath = path.join(ROOT, normalized);
  if (!filePath.startsWith(ROOT + path.sep) && filePath !== path.join(ROOT, 'index.html')) return sendJson(res, 403, { error: 'Acesso negado.' });
  fs.readFile(filePath, (error, content) => {
    if (error) return sendJson(res, 404, { error: 'Arquivo não encontrado.' });
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME_TYPES[ext] || 'application/octet-stream',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; manifest-src 'self'; worker-src 'self'"
    });
    res.end(headOnly ? undefined : content);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (req.method !== 'GET' && req.method !== 'HEAD') return sendJson(res, 405, { error: 'Método não permitido.' });
  if (req.method === 'HEAD' && url.pathname.startsWith('/api/')) return sendJson(res, 405, { error: 'Método não permitido.' });
  if (url.pathname === '/api/health') return sendJson(res, 200, { ok: true, ticker: 'MXRF11', brapiTokenConfigured: Boolean(BRAPI_TOKEN) });
  if (url.pathname === '/api/history') return getHistory(url, res);
  if (url.pathname === '/api/indicators') return getIndicators(res);
  if (url.pathname === '/api/news') return getNews(res);
  return serveStatic(url.pathname, res, req.method === 'HEAD');
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`MXRF11 Analytics disponível em http://localhost:${PORT}`);
  console.log(`Token brapi: ${BRAPI_TOKEN ? 'configurado' : 'não configurado (consulte os limites do provedor)'}`);
});
