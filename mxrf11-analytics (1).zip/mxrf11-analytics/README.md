# MXRF11 Analytics

Painel web open source para acompanhamento **educacional** do fundo imobiliário MXRF11 (Maxi Renda FII). O projeto é responsivo e pode ser instalado como PWA em navegadores compatíveis.

> **Importante:** esta aplicação não é uma corretora, não executa ordens e não fornece recomendação personalizada de compra ou venda. Indicadores técnicos e classificações de notícias são descritivos/preliminares; não preveem retornos nem substituem a leitura dos documentos oficiais.

## Recursos da primeira versão

- Gráfico de preço de fechamento e linha de tendência linear.
- Filtros de período: 1 ano, 2 anos, 5 anos, máximo disponível e intervalo personalizado.
- Médias móveis de 20 e 50 pregões, volatilidade anualizada estimada e maior recuo observado.
- Indicadores fundamentalistas: P/VP, dividend yield de 12 meses, patrimônio líquido e cotistas.
- Feed de notícias do Google News RSS com classificação simples por palavras-chave.
- Modo demonstração claramente identificado quando a fonte real não está disponível.
- Preferências salvas no dispositivo: perfil conservador, frequência de verificação de 15 minutos e foco em rendimentos + valorização.
- Avaliação explicável com bloqueio de pontuação quando faltam dados reais ou indicadores fundamentais.
- Layout adaptável a PC, Android e iOS; shell PWA com cache básico para abrir a interface sem conexão.

## Requisitos

- Node.js 18 ou superior (usa `fetch` nativo; não precisa instalar dependências).
- Conexão com a internet para consultar os provedores externos.

## Executar localmente

```bash
node server.js
```

Abra `http://localhost:3000` no navegador.

### Configurar chave opcional da brapi

O servidor funciona sem chave para os dados/tickers que o plano público do provedor permitir. Para habilitar um plano autenticado, configure `BRAPI_TOKEN` como variável de ambiente **somente no servidor**.

PowerShell:

```powershell
$env:BRAPI_TOKEN="SUA_CHAVE"
node server.js
```

Linux/macOS:

```bash
BRAPI_TOKEN="SUA_CHAVE" node server.js
```

Nunca coloque a chave em `app.js`, `index.html`, repositório público ou código executado no navegador. Consulte os limites, preços e termos do provedor antes de publicar o serviço.

## Integrações atuais

### Histórico e indicadores

O backend consulta os endpoints de fundos imobiliários da brapi.dev e encaminha os resultados ao navegador:

- `GET /api/v2/fii/historical?symbols=MXRF11&startDate=...&endDate=...`
- `GET /api/v2/fii/indicators?symbols=MXRF11`

A série diária é exibida com o preço de fechamento. A documentação do provedor informa que `adjustedClose` considera proventos e eventos de cotas; para uma análise de retorno total, esse campo deve ser tratado separadamente do preço de mercado.

### Notícias

O backend consulta o Google News RSS por `MXRF11` e `Maxi Renda`, mantém cache de cinco minutos e devolve o link para a matéria original. Isso **não é uma garantia de cobertura em tempo real**; a publicação, indexação e disponibilidade dependem da fonte.

A etiqueta de impacto é uma heurística local e transparente baseada em palavras-chave no título. Ela pode errar contexto, ironia, negação e relevância. Não é análise de sentimento por IA nem deve ser interpretada como sinal de negociação.

## Rotas locais

- `GET /api/health` — estado básico do servidor.
- `GET /api/history?startDate=YYYY-MM-DD&endDate=YYYY-MM-DD` — histórico diário de MXRF11.
- `GET /api/indicators` — indicadores mais recentes retornados pelo provedor.
- `GET /api/news` — notícias encontradas pelo RSS.

## Publicação online (Railway)

O projeto inclui `package.json` com o comando `npm start`, detectável pela plataforma. Para publicar usando o fluxo de implantação por GitHub:

1. Crie um repositório no GitHub e envie o conteúdo desta pasta (não envie `.env`).
2. Na Railway, crie um projeto a partir do repositório GitHub. O serviço Node.js pode ser detectado automaticamente a partir do `package.json`.
3. Confirme que o comando de inicialização é `npm start`. A rota `/api/health` está disponível para teste após a publicação.
4. Se tiver uma chave da brapi, cadastre `BRAPI_TOKEN` nas variáveis/segredos do serviço na Railway. Não compartilhe a chave no chat nem a coloque no código.
5. Gere um domínio público HTTPS nas configurações de rede do serviço.
6. Abra o endereço no PC ou celular. Em navegadores compatíveis, use “Adicionar à tela inicial” para instalar o PWA.

A publicação só estará concluída depois que o serviço estiver implantado e o domínio responder à rota `/api/health`. Uma conta da plataforma e autorização de acesso ao projeto são necessárias para executar essa etapa.

Publique a pasta em uma hospedagem que execute Node.js e configure `BRAPI_TOKEN` como segredo/variável de ambiente no painel da hospedagem. Use HTTPS. Não publique uma chave em repositório. Para instalar em celulares, abra o endereço HTTPS em um navegador compatível e use a opção de instalação/adicionar à tela inicial.

A versão atual é um ponto de partida. Antes de uso público, acrescente testes, monitoramento de disponibilidade, limites de requisição, logs sem dados sensíveis, política de privacidade e validação dos termos/licenças dos provedores.

## Preferências e motor de análise

As preferências iniciais são **Conservador**, tentativa de atualização a cada **15 minutos** e foco em **rendimentos + valorização**. Elas podem ser alteradas na interface e ficam salvas no armazenamento local do navegador. A frequência controla tentativas de atualização; não altera a frequência de publicação da fonte. Como o endpoint atual fornece histórico diário, repetir a consulta a cada 15 minutos não cria cotação intradiária nem tempo real.

O motor conservador exige histórico real com pelo menos 50 observações e indicadores P/VP e dividend yield disponíveis antes de emitir uma leitura consolidada. Se faltarem dados, a tela informa análise incompleta em vez de atribuir nota artificial. A leitura usa alertas descritivos de tendência, volatilidade, recuo, P/VP e DY; não estima probabilidade de retorno nem recomenda compra ou venda.

## Limitações conhecidas da versão 0.1

- A cotação usa a série histórica diária do provedor, não um feed tick a tick nem livro de ofertas em tempo real.
- Não existe comparação de “preço por corretora”: as corretoras mostram o mercado da B3; taxas e condições de execução podem variar.
- O cálculo técnico é simples e serve para estudo. Não considera todos os fatores que afetam um FII, como qualidade dos CRIs, inadimplência, indexadores, emissões, liquidez, gestão e mudanças macroeconômicas.
- O PWA armazena apenas os arquivos da interface; os dados de mercado e notícias precisam de conexão.

## Licença

MIT — veja `LICENSE`.
