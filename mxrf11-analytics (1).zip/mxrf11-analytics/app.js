'use strict';

const $ = (id) => document.getElementById(id);
const brl = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
const number = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 2 });
const integer = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 0 });
const START_OF_TRADING = '2012-04-13';
const DEFAULT_SETTINGS = { profile: 'conservative', refreshMs: 15 * 60 * 1000, focus: 'both' };
const state = { history: [], mode: 'demo', indicators: null, newsIsDemo: true, settings: { ...DEFAULT_SETTINGS }, refreshTimer: null };

function isoDate(date) {
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function dateFromIso(value) {
  const [year, month, day] = value.split('-').map(Number);
  return new Date(year, month - 1, day, 12, 0, 0);
}
function shiftYears(date, years) {
  const copy = new Date(date);
  copy.setFullYear(copy.getFullYear() - years);
  return copy;
}
function formatDate(value) {
  const d = typeof value === 'string' ? dateFromIso(value) : new Date(value);
  return d.toLocaleDateString('pt-BR');
}
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
}
function validPoint(point) {
  return point && Number.isFinite(Number(point.close)) && Number(point.close) > 0 && Number.isFinite(new Date(point.date).getTime());
}

function createDemoHistory(startDate, endDate) {
  const start = dateFromIso(startDate);
  const end = dateFromIso(endDate);
  const points = [];
  let price = 9.65;
  let index = 0;
  for (let date = new Date(start); date <= end; date.setDate(date.getDate() + 1)) {
    const day = date.getDay();
    if (day === 0 || day === 6) continue;
    const wave = Math.sin(index * 0.105) * 0.026 + Math.cos(index * 0.031) * 0.018;
    const drift = Math.sin(index * 0.008) * 0.00015;
    price = Math.max(7.2, Math.min(11.8, price * (1 + wave * 0.12 + drift)));
    const open = price * (1 + Math.sin(index * 1.71) * 0.003);
    const close = price * (1 + Math.cos(index * 1.13) * 0.0035);
    const volume = Math.round(500000 + Math.abs(Math.sin(index * .29)) * 1400000 + (index % 17) * 12000);
    points.push({ date: isoDate(date), open, high: Math.max(open, close) * 1.006, low: Math.min(open, close) * .994, close, adjustedClose: close, volume });
    price = close;
    index += 1;
  }
  return points;
}

function getDefaultPeriod(preset) {
  const now = new Date();
  const endDate = isoDate(now);
  if (preset === 'max') return { startDate: START_OF_TRADING, endDate };
  const years = preset === '2y' ? 2 : preset === '5y' ? 5 : 1;
  return { startDate: isoDate(shiftYears(now, years)), endDate };
}

function setConnection(connected, text) {
  $('connectionText').textContent = text;
  document.querySelector('.status-dot').classList.toggle('connected', connected);
}

async function requestJson(url) {
  const response = await fetch(url, { headers: { Accept: 'application/json' } });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || `HTTP ${response.status}`);
  return body;
}

async function loadHistory(startDate, endDate) {
  try {
    const params = new URLSearchParams({ startDate, endDate });
    const result = await requestJson(`/api/history?${params}`);
    if (!Array.isArray(result.data) || result.data.length < 2) throw new Error('A fonte não retornou pontos suficientes.');
    const data = result.data.filter(validPoint).sort((a, b) => new Date(a.date) - new Date(b.date));
    if (data.length < 2) throw new Error('Série histórica inválida.');
    state.history = data;
    state.mode = 'real';
    $('demoNotice').hidden = true;
    $('dataSource').textContent = result.source || 'brapi.dev';
    setConnection(true, 'Fonte de dados conectada');
  } catch (error) {
    state.history = createDemoHistory(startDate, endDate);
    state.mode = 'demo';
    $('demoNotice').hidden = false;
    $('dataSource').textContent = 'Série simulada · não representa o mercado';
    setConnection(false, 'Modo demonstração');
    $('periodMessage').textContent = `Não foi possível obter a série real (${error.message}). O gráfico está usando dados simulados.`;
  }
  renderAll();
}

async function loadIndicators() {
  try {
    state.indicators = await requestJson('/api/indicators');
  } catch (_) {
    state.indicators = null;
  }
  renderFundamentals();
  if (state.history.length >= 2) renderAssessment(calculateStats(state.history));
}

const demoNews = [
  { title: 'Exemplo ilustrativo: relatório gerencial e composição da carteira', source: 'Notícia demonstrativa', date: new Date().toISOString(), link: '', impact: 'neutral' },
  { title: 'Exemplo ilustrativo: cenário de juros e fundos imobiliários', source: 'Notícia demonstrativa', date: new Date(Date.now() - 86400000).toISOString(), link: '', impact: 'neutral' },
  { title: 'Exemplo ilustrativo: comunicados e rendimentos do fundo', source: 'Notícia demonstrativa', date: new Date(Date.now() - 2 * 86400000).toISOString(), link: '', impact: 'neutral' }
];

function classifyImpact(title) {
  const text = String(title || '').toLocaleLowerCase('pt-BR');
  const negative = ['calote', 'inadimpl', 'default', 'prejuízo', 'prejuizo', 'queda', 'risco', 'fraude', 'processo', 'atraso', 'rebaixamento', 'desocupação', 'desocupacao', 'emissão', 'emissao'];
  const positive = ['lucro', 'alta', 'aumento', 'crescimento', 'recorde', 'valorização', 'valorizacao', 'amortização', 'amortizacao', 'ganho', 'aquisição', 'aquisicao'];
  const hasNegative = negative.some((word) => text.includes(word));
  const hasPositive = positive.some((word) => text.includes(word));
  if (hasNegative && !hasPositive) return { label: 'Atenção', className: 'negative' };
  if (hasPositive && !hasNegative) return { label: 'Possível efeito favorável', className: 'positive' };
  return { label: 'Indefinido', className: 'neutral' };
}

async function loadNews() {
  try {
    const result = await requestJson('/api/news');
    const news = Array.isArray(result.items) ? result.items : [];
    state.newsIsDemo = false;
    renderNews(news);
    $('newsUpdated').textContent = `Verificado às ${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
  } catch (_) {
    state.newsIsDemo = true;
    renderNews(demoNews);
    $('newsUpdated').textContent = 'Feed indisponível · exemplos ilustrativos';
  }
}

function movingAverage(points, windowSize) {
  if (points.length < windowSize) return null;
  const recent = points.slice(-windowSize);
  return recent.reduce((sum, point) => sum + Number(point.close), 0) / windowSize;
}

function linearRegression(values) {
  const n = values.length;
  if (n < 2) return { slope: 0, intercept: values[0] || 0 };
  const xs = values.map((_, index) => index);
  const meanX = (n - 1) / 2;
  const meanY = values.reduce((sum, value) => sum + value, 0) / n;
  let numerator = 0;
  let denominator = 0;
  values.forEach((value, index) => {
    numerator += (index - meanX) * (value - meanY);
    denominator += (index - meanX) ** 2;
  });
  const slope = denominator ? numerator / denominator : 0;
  return { slope, intercept: meanY - slope * meanX };
}

function calculateStats(points) {
  const closes = points.map((point) => Number(point.close));
  const first = closes[0];
  const last = closes[closes.length - 1];
  const min = Math.min(...closes);
  const max = Math.max(...closes);
  const change = first ? (last / first - 1) * 100 : 0;
  const volume = points.reduce((sum, point) => sum + (Number(point.volume) || 0), 0) / points.length;
  const regression = linearRegression(closes);
  const slopePct = last ? (regression.slope * Math.max(1, closes.length - 1) / last) * 100 : 0;
  const trend = slopePct > 1.2 ? 'positive' : slopePct < -1.2 ? 'negative' : 'neutral';
  const dailyReturns = [];
  for (let index = 1; index < closes.length; index += 1) dailyReturns.push(closes[index] / closes[index - 1] - 1);
  const mean = dailyReturns.length ? dailyReturns.reduce((sum, value) => sum + value, 0) / dailyReturns.length : 0;
  const variance = dailyReturns.length > 1 ? dailyReturns.reduce((sum, value) => sum + (value - mean) ** 2, 0) / (dailyReturns.length - 1) : 0;
  const volatility = Math.sqrt(variance * 252) * 100;
  let peak = closes[0];
  let maxDrawdown = 0;
  closes.forEach((price) => {
    peak = Math.max(peak, price);
    if (peak > 0) maxDrawdown = Math.min(maxDrawdown, (price / peak - 1) * 100);
  });
  const sma20 = movingAverage(points, 20);
  const sma50 = movingAverage(points, 50);
  const distanceSma = sma50 ? (last / sma50 - 1) * 100 : null;
  return { first, last, min, max, change, volume, trend, regression, volatility, maxDrawdown, sma20, sma50, distanceSma };
}

function money(value) { return Number.isFinite(value) ? brl.format(value) : '—'; }
function pct(value, digits = 2) { return Number.isFinite(value) ? `${value > 0 ? '+' : ''}${value.toFixed(digits).replace('.', ',')}%` : '—'; }

function renderMetrics(stats, points) {
  $('lastPrice').textContent = money(stats.last);
  $('lastPriceDate').textContent = `Fechamento em ${formatDate(points[points.length - 1].date)}`;
  $('periodChange').textContent = pct(stats.change);
  $('periodChange').classList.toggle('positive-text', stats.change > 0);
  $('periodChange').classList.toggle('negative-text', stats.change < 0);
  $('periodRange').textContent = `${money(stats.min)} / ${money(stats.max)}`;
  $('averageVolume').textContent = integer.format(stats.volume);
  const label = stats.trend === 'positive' ? 'Tendência ascendente' : stats.trend === 'negative' ? 'Tendência descendente' : 'Tendência lateral / indefinida';
  $('trendBadge').textContent = label;
  $('trendBadge').className = `trend-badge ${stats.trend}`;
  $('chartPeriodLabel').textContent = `${formatDate(points[0].date)} a ${formatDate(points[points.length - 1].date)}`;
  $('axisStart').textContent = formatDate(points[0].date);
  $('axisEnd').textContent = formatDate(points[points.length - 1].date);
}

function svgText(x, y, text, anchor = 'start') {
  return `<text x="${x}" y="${y}" text-anchor="${anchor}" fill="#71839a" font-size="10" font-family="system-ui, sans-serif">${escapeHtml(text)}</text>`;
}

function renderPriceChart(points, stats) {
  const width = 900, height = 330;
  const left = 58, right = 16, top = 16, bottom = 26;
  const plotW = width - left - right, plotH = height - top - bottom;
  const closes = points.map((p) => Number(p.close));
  let min = Math.min(...closes), max = Math.max(...closes);
  const pad = Math.max((max - min) * .14, .08);
  min -= pad; max += pad;
  const x = (i) => left + (i / Math.max(1, points.length - 1)) * plotW;
  const y = (value) => top + ((max - value) / (max - min)) * plotH;
  let svg = '';
  for (let i = 0; i <= 4; i += 1) {
    const value = min + (max - min) * (i / 4);
    const yy = y(value);
    svg += `<line x1="${left}" y1="${yy}" x2="${width - right}" y2="${yy}" stroke="#29394d" stroke-width="1" stroke-dasharray="3 6"/>`;
    svg += svgText(left - 9, yy + 3, `R$ ${value.toFixed(2).replace('.', ',')}`, 'end');
  }
  const line = closes.map((value, index) => `${index === 0 ? 'M' : 'L'} ${x(index).toFixed(2)} ${y(value).toFixed(2)}`).join(' ');
  const trendStart = stats.regression.intercept;
  const trendEnd = stats.regression.intercept + stats.regression.slope * (closes.length - 1);
  const trendColor = stats.trend === 'negative' ? '#ff8d92' : stats.trend === 'positive' ? '#5ed6a0' : '#f2c879';
  const area = `${line} L ${x(points.length - 1)} ${top + plotH} L ${x(0)} ${top + plotH} Z`;
  svg += `<path d="${area}" fill="rgba(112,183,255,.08)"/>`;
  svg += `<path d="${line}" fill="none" stroke="#70b7ff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>`;
  svg += `<line x1="${x(0)}" y1="${y(trendStart)}" x2="${x(points.length - 1)}" y2="${y(trendEnd)}" stroke="${trendColor}" stroke-width="2" stroke-dasharray="7 6" opacity=".95"/>`;
  svg += `<circle cx="${x(points.length - 1)}" cy="${y(closes[closes.length - 1])}" r="4.5" fill="#70b7ff" stroke="#d8edff" stroke-width="2"/>`;
  $('priceChart').innerHTML = svg;
}

function renderVolumeChart(points) {
  const width = 620, height = 190;
  const left = 10, right = 10, top = 12, bottom = 17;
  const plotW = width - left - right, plotH = height - top - bottom;
  const values = points.map((point) => Number(point.volume) || 0);
  const max = Math.max(...values, 1);
  const bucketSize = Math.max(1, Math.ceil(points.length / 90));
  const buckets = [];
  for (let index = 0; index < points.length; index += bucketSize) {
    const sample = points.slice(index, index + bucketSize);
    buckets.push({ volume: sample.reduce((sum, p) => sum + (Number(p.volume) || 0), 0) / sample.length, close: Number(sample[sample.length - 1].close), prior: Number(sample[0].open || sample[0].close) });
  }
  const barW = Math.max(2, (plotW / buckets.length) * .65);
  let svg = `<line x1="${left}" y1="${top + plotH}" x2="${width - right}" y2="${top + plotH}" stroke="#29394d"/>`;
  buckets.forEach((bucket, index) => {
    const barH = (bucket.volume / max) * plotH;
    const xx = left + (index / buckets.length) * plotW + (plotW / buckets.length - barW) / 2;
    const yy = top + plotH - barH;
    const color = bucket.close >= bucket.prior ? '#5ed6a0' : '#ff8d92';
    svg += `<rect x="${xx.toFixed(2)}" y="${yy.toFixed(2)}" width="${barW.toFixed(2)}" height="${barH.toFixed(2)}" rx="1.5" fill="${color}" opacity=".75"/>`;
  });
  $('volumeChart').innerHTML = svg;
}

function renderTechnical(stats) {
  $('sma20').textContent = money(stats.sma20);
  $('sma50').textContent = money(stats.sma50);
  $('volatility').textContent = Number.isFinite(stats.volatility) ? pct(stats.volatility) : '—';
  $('maxDrawdown').textContent = Number.isFinite(stats.maxDrawdown) ? pct(stats.maxDrawdown) : '—';
  $('distanceSma').textContent = stats.distanceSma === null ? 'Histórico insuficiente' : pct(stats.distanceSma);
  $('distanceSma').className = stats.distanceSma > 0 ? 'positive-text' : stats.distanceSma < 0 ? 'negative-text' : '';

  const tone = $('scenarioTone');
  tone.className = `scenario-tone ${stats.trend}`;
  tone.textContent = stats.trend === 'positive' ? 'Tendência ascendente observada' : stats.trend === 'negative' ? 'Tendência descendente observada' : 'Movimento lateral / inconclusivo';
  let text = `No intervalo selecionado, o preço variou ${pct(stats.change)}. `;
  text += stats.trend === 'positive'
    ? 'A regressão linear apresenta inclinação positiva. Isso descreve o comportamento passado e não confirma continuidade da alta.'
    : stats.trend === 'negative'
      ? 'A regressão linear apresenta inclinação negativa. Isso descreve o comportamento passado e não confirma continuidade da queda.'
      : 'A inclinação estimada não aponta uma direção predominante suficientemente forte neste intervalo.';
  text += stats.sma50 ? ` O último fechamento está ${pct(stats.distanceSma)} em relação à média móvel de 50 pregões.` : ' Ainda não há observações suficientes para calcular a média móvel de 50 pregões.';
  text += ` A volatilidade anualizada estimada foi de ${pct(stats.volatility)} e o maior recuo observado, de ${pct(stats.maxDrawdown)}.`;
  $('scenarioText').textContent = text;
}

function renderFundamentals() {
  const fund = state.indicators?.fiis?.find((item) => item.symbol === 'MXRF11') || state.indicators?.fiis?.[0];
  if (!fund) {
    ['pvp', 'dy12', 'equity', 'investors'].forEach((id) => { $(id).textContent = '—'; });
    $('fundamentalsDate').textContent = 'Indicadores indisponíveis';
    return;
  }
  $('pvp').textContent = Number.isFinite(Number(fund.priceToNav)) ? Number(fund.priceToNav).toFixed(2).replace('.', ',') : '—';
  $('dy12').textContent = Number.isFinite(Number(fund.dividendYield12m)) ? `${(Number(fund.dividendYield12m) * 100).toFixed(2).replace('.', ',')}%` : '—';
  $('equity').textContent = Number.isFinite(Number(fund.equity)) ? brl.format(Number(fund.equity)) : '—';
  $('investors').textContent = Number.isFinite(Number(fund.totalInvestors)) ? integer.format(Number(fund.totalInvestors)) : '—';
  $('fundamentalsDate').textContent = fund.asOfDate ? `Referência: ${String(fund.asOfDate).slice(0, 10)}` : 'Data de referência não informada';
}

function renderNews(items) {
  const list = $('newsList');
  if (!items.length) {
    list.innerHTML = '<div class="empty-state">Nenhuma notícia encontrada para MXRF11.</div>';
    return;
  }
  list.innerHTML = items.slice(0, 6).map((item) => {
    const impact = item.impact ? { label: item.impact.label || item.impact, className: item.impact.className || 'neutral' } : classifyImpact(item.title);
    const published = item.date ? new Date(item.date) : null;
    const dateLabel = published && !Number.isNaN(published.getTime()) ? published.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) : 'Data não informada';
    const title = escapeHtml(item.title || 'Notícia sem título');
    const source = escapeHtml(item.source || 'Fonte não identificada');
    const meta = `${source} · ${dateLabel}`;
    const content = `<span class="news-title">${title}</span><span class="news-meta"><span>${meta}</span><span class="impact-tag ${impact.className}">${escapeHtml(impact.label)}</span></span>`;
    if (item.link && /^https:\/\//i.test(item.link)) return `<a class="news-item" href="${escapeHtml(item.link)}" target="_blank" rel="noopener noreferrer">${content}</a>`;
    return `<div class="news-item">${content}</div>`;
  }).join('');
  if (state.newsIsDemo) {
    list.insertAdjacentHTML('afterbegin', '<div class="small-muted demo-news-note">Exemplos ilustrativos — feed real não conectado.</div>');
  }
}

function loadSettings() {
  try {
    const saved = JSON.parse(localStorage.getItem('mxrf11-analytics-settings') || '{}');
    state.settings = { ...DEFAULT_SETTINGS, ...saved };
  } catch (_) { state.settings = { ...DEFAULT_SETTINGS }; }
  $('analysisProfile').value = state.settings.profile;
  $('refreshFrequency').value = String(state.settings.refreshMs);
  $('investmentFocus').value = state.settings.focus;
  renderSettingsLabel();
}

function renderSettingsLabel() {
  const profiles = { conservative: 'Conservador', balanced: 'Equilibrado', technical: 'Técnico' };
  $('scoreProfile').textContent = `Perfil ${profiles[state.settings.profile] || profiles.conservative}`;
  $('settingsSaved').textContent = 'Preferências salvas neste dispositivo';
}

function saveSettings() {
  state.settings = {
    profile: $('analysisProfile').value,
    refreshMs: Number($('refreshFrequency').value),
    focus: $('investmentFocus').value
  };
  localStorage.setItem('mxrf11-analytics-settings', JSON.stringify(state.settings));
  renderSettingsLabel();
  scheduleRefresh();
  $('settingsSaved').textContent = 'Preferências salvas';
}

function renderAssessment(stats) {
  const fund = state.indicators?.fiis?.find((item) => item.symbol === 'MXRF11') || state.indicators?.fiis?.[0];
  const realHistory = state.mode === 'real';
  const technicalReady = realHistory && stats && state.history.length >= 50;
  const fundamentalReady = fund && Number.isFinite(Number(fund.priceToNav)) && Number.isFinite(Number(fund.dividendYield12m));
  $('technicalAssessment').textContent = !technicalReady ? 'Dados insuficientes' : stats.trend === 'positive' && stats.distanceSma > 0 ? 'Tendência positiva' : stats.trend === 'negative' && stats.distanceSma < 0 ? 'Tendência negativa' : 'Sinais mistos';
  $('fundamentalAssessment').textContent = !fundamentalReady ? 'Dados insuficientes' : `P/VP ${Number(fund.priceToNav).toFixed(2).replace('.', ',')} · DY 12m ${(Number(fund.dividendYield12m) * 100).toFixed(2).replace('.', ',')}%`;
  $('riskAssessment').textContent = !technicalReady ? 'Não calculado' : stats.volatility >= 25 || stats.maxDrawdown <= -15 ? 'Atenção elevada' : stats.volatility >= 12 || stats.maxDrawdown <= -8 ? 'Atenção moderada' : 'Risco histórico contido';
  const ready = technicalReady && fundamentalReady;
  if (!ready) {
    $('overallAssessment').textContent = 'Análise incompleta';
    $('assessmentExplanation').textContent = 'O perfil conservador exige histórico real suficiente e indicadores fundamentalistas atualizados. Dados simulados ou campos ausentes não geram pontuação nem sinal de compra.';
    return;
  }
  const risks = stats.volatility >= 25 || stats.maxDrawdown <= -15;
  const trendWeak = stats.trend === 'negative' && stats.distanceSma < 0;
  const pvp = Number(fund.priceToNav);
  const dy = Number(fund.dividendYield12m) * 100;
  const fundamentalCaution = pvp > 1.05 || dy <= 0;
  const cautionCount = [risks, trendWeak, fundamentalCaution].filter(Boolean).length;
  const conclusion = cautionCount >= 2 ? 'Atenção: riscos relevantes' : cautionCount === 1 ? 'Aguardar confirmação' : 'Indicadores sem alerta forte';
  $('overallAssessment').textContent = conclusion;
  const focusText = state.settings.focus === 'income' ? 'O foco configurado é rendimentos; DY passado não garante pagamentos futuros.' : state.settings.focus === 'appreciation' ? 'O foco configurado é valorização; tendência passada não prevê preço futuro.' : 'A análise considera rendimentos e valorização separadamente.';
  $('assessmentExplanation').textContent = `${focusText} Alertas considerados: ${cautionCount} de 3. Perfil conservador prioriza preservação de capital e exige confirmação dos dados oficiais. Esta leitura é informativa, não uma ordem ou recomendação de investimento.`;
}

function scheduleRefresh() {
  if (state.refreshTimer) window.clearInterval(state.refreshTimer);
  state.refreshTimer = window.setInterval(refreshAll, state.settings.refreshMs);
}

function renderAll() {
  if (state.history.length < 2) return;
  const stats = calculateStats(state.history);
  renderMetrics(stats, state.history);
  renderPriceChart(state.history, stats);
  renderVolumeChart(state.history);
  renderTechnical(stats);
  renderAssessment(stats);
  $('updatedAt').textContent = new Date().toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
}

async function applyPeriod() {
  const startDate = $('startDate').value;
  const endDate = $('endDate').value;
  const today = isoDate(new Date());
  if (!startDate || !endDate || startDate < START_OF_TRADING || startDate > endDate || endDate > today) {
    $('periodMessage').textContent = `Informe um intervalo válido entre ${formatDate(START_OF_TRADING)} e ${formatDate(today)}.`;
    return;
  }
  $('periodMessage').textContent = 'Consultando histórico…';
  await loadHistory(startDate, endDate);
  $('periodMessage').textContent = state.mode === 'real' ? 'Período atualizado com dados recebidos da fonte.' : 'Exibindo série simulada. Confira a configuração do provedor para carregar dados reais.';
}

function onPresetChange() {
  const preset = $('rangePreset').value;
  if (preset === 'custom') return;
  const range = getDefaultPeriod(preset);
  $('startDate').value = range.startDate;
  $('endDate').value = range.endDate;
}

async function refreshAll() {
  $('refreshButton').disabled = true;
  $('refreshButton').textContent = '…';
  await Promise.all([applyPeriod(), loadIndicators(), loadNews()]);
  if (state.history.length >= 2) renderAssessment(calculateStats(state.history));
  $('refreshButton').disabled = false;
  $('refreshButton').textContent = '↻';
}

async function init() {
  const today = isoDate(new Date());
  const initial = getDefaultPeriod('1y');
  $('startDate').min = START_OF_TRADING;
  $('startDate').max = today;
  $('endDate').min = START_OF_TRADING;
  $('endDate').max = today;
  $('startDate').value = initial.startDate;
  $('endDate').value = initial.endDate;
  $('rangePreset').addEventListener('change', onPresetChange);
  $('applyPeriod').addEventListener('click', applyPeriod);
  $('refreshButton').addEventListener('click', refreshAll);
  $('saveSettings').addEventListener('click', saveSettings);
  loadSettings();

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  }

  // A tela abre imediatamente com dados claramente identificados como simulados.
  state.history = createDemoHistory(initial.startDate, initial.endDate);
  renderAll();
  renderNews(demoNews);
  $('updatedAt').textContent = 'Aguardando fonte real';

  // O servidor local tenta conectar as fontes reais sem expor chaves no navegador.
  await Promise.all([loadHistory(initial.startDate, initial.endDate), loadIndicators(), loadNews()]);
  scheduleRefresh();
}

document.addEventListener('DOMContentLoaded', init);
